package com.company;


import java.io.*;
import java.util.Random;
import java.util.Scanner;

public class Main {

    public static void main(String[] args) throws IOException {
        kezdoFrame k = new kezdoFrame();
    }
}
